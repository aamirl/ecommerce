/**
 * Created by baiyu on 3/10/16.
 */
var configuration = {
    key: "key"
};

var schedulerRestCall = function(body, callback) {

    var time = Date.now();
    var crypto = require('crypto');

    var str_to_sign = "";
    var b = JSON.stringify(body);

    str_to_sign = str_to_sign + 'POST' + "\n" + time + "\n" + b;

    var hash = crypto.createHmac('sha256', configuration.key).update(str_to_sign).digest('hex');

    var token = new Buffer(hash).toString('base64');

    var https = require('https');
    var data = '';


    // options for POST
    var optionspost = {
        host : 'mq.sellyx.com',
        port : 443,
        path : '/?time=' + time + '&token=' + token,
        headers: { "Content-Type" : "application/json" },
        method : 'POST'
    };

    var req = https.request(optionspost, function (res) {
        res.setEncoding('utf8');

        res.on('data', function(d) {
            data += d;
        });

        res.on('end', function() {
            callback(data);
        });
    });

    req.write(b);
    req.end();
};

module.exports = {
    config: function(signingkey) {
        configuration.key = signingkey;
    },
    GSSRestSchedule: function(type, endpoint, content_type, body, exp) {
        var to_send = {type: 107, endpoint: type + " " + endpoint + " " + content_type,
            message: JSON.stringify(body), expiration: exp};
        schedulerRestCall(to_send, function(data) {
            var obj = JSON.parse(data);
            if (obj.success) {
                return true;
            } else {
                return obj.failure.msg;
            }
        });
    },
    GSSSMSSchedule: function(endpoint, body, exp) {
        var to_send = {type: 109, endpoint: endpoint, message: body, expiration: exp};
        schedulerRestCall(to_send, function(data) {
            var obj = JSON.parse(data);
            if (obj.success) {
                return true;
            } else {
                return obj.failure.msg;
            }
        });
    },
    GSSWebSocketSchedule: function(client_id, client_key, body, exp) {
        var to_send = {type: 105, endpoint: client_id + '.' + client_key,
            message: JSON.stringify(body), expiration: exp};
        schedulerRestCall(to_send, function(data) {
            var obj = JSON.parse(data);
            if (obj.success) {
                return true;
            } else {
                return obj.failure.msg;
            }
        });
    },
    GSSPushGCMSchedule: function(endpoint, type, title, body, payload, exp) {
        var message = {
            type: type,
            title: title,
            body: body,
            payload: payload
        };
        var to_send = {type: 102, endpoint: endpoint, message: JSON.stringify(encodeURIComponent(message)), expiration: exp};
        console.log(to_send);
        schedulerRestCall(to_send, function(data) {
            var obj = JSON.parse(data);
            if (obj.success) {
                return true;
            } else {
                return obj.failure.msg;
            }
        });
    }
};